const express = require('express');
const app = express();
const port = 4000;

const morgan = require('morgan');
const bodyParser = require('body-parser');
const cors = require('cors');
const { MongoClient, ObjectId } = require('mongodb');

app.use(morgan('combined'));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());

const client = new MongoClient('mongodb://127.0.0.1:27017');

async function startServer() {
  try {
    await client.connect();
    console.log('Connected MongoDB');

    const database = client.db('FashionData');
    const fashionCollection = database.collection('Fashion');

    app.get('/', (req, res) => {
      res.send('Server Fashion is running');
    });

    // GET all fashions - sort by createdAt desc
    app.get('/fashions', async (req, res) => {
      try {
        const result = await fashionCollection.find({}).sort({ createdAt: -1 }).toArray();
        res.json(result);
      } catch (error) {
        console.error(error);
        res.status(500).send({ message: 'Error getting fashions' });
      }
    });

    // GET fashions by style
    app.get('/fashions/style/:style', async (req, res) => {
      try {
        const style = req.params.style;
        const result = await fashionCollection.find({ style: style }).sort({ createdAt: -1 }).toArray();
        res.json(result);
      } catch (error) {
        console.error(error);
        res.status(500).send({ message: 'Error filtering fashions by style' });
      }
    });

    // GET one fashion by id
    app.get('/fashions/:id', async (req, res) => {
      try {
        const id = req.params.id;
        const result = await fashionCollection.findOne({ _id: new ObjectId(id) });

        if (!result) {
          return res.status(404).send({ message: 'Fashion not found' });
        }

        res.json(result);
      } catch (error) {
        console.error(error);
        res.status(500).send({ message: 'Error getting fashion by id' });
      }
    });

    // POST create new fashion
    app.post('/fashions', async (req, res) => {
      try {
        const newFashion = {
          title: req.body.title,
          details: req.body.details,
          thumbnail: req.body.thumbnail,
          style: req.body.style,
          createdAt: new Date()
        };

        const result = await fashionCollection.insertOne(newFashion);
        res.status(201).send({
          message: 'Create fashion successfully',
          insertedId: result.insertedId
        });
      } catch (error) {
        console.error(error);
        res.status(500).send({ message: 'Error creating fashion' });
      }
    });

    // PUT update fashion
    app.put('/fashions/:id', async (req, res) => {
      try {
        const id = req.params.id;

        const updatedFashion = {
          $set: {
            title: req.body.title,
            details: req.body.details,
            thumbnail: req.body.thumbnail,
            style: req.body.style
          }
        };

        const result = await fashionCollection.updateOne(
          { _id: new ObjectId(id) },
          updatedFashion
        );

        res.send({
          message: 'Update fashion successfully',
          matchedCount: result.matchedCount,
          modifiedCount: result.modifiedCount
        });
      } catch (error) {
        console.error(error);
        res.status(500).send({ message: 'Error updating fashion' });
      }
    });

    // DELETE fashion
    app.delete('/fashions/:id', async (req, res) => {
      try {
        const id = req.params.id;

        const result = await fashionCollection.deleteOne({ _id: new ObjectId(id) });

        res.send({
          message: 'Delete fashion successfully',
          deletedCount: result.deletedCount
        });
      } catch (error) {
        console.error(error);
        res.status(500).send({ message: 'Error deleting fashion' });
      }
    });

    app.listen(port, () => {
      console.log(`Server running at http://localhost:${port}`);
    });
  } catch (error) {
    console.error('MongoDB connection error:', error);
  }
}

startServer();