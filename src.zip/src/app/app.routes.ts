import { Routes } from '@angular/router';
import { FashionList } from './fashion-list/fashion-list';
import { FashionForm } from './fashion-form/fashion-form';
import { FashionDetail } from './fashion-detail/fashion-detail';

export const routes: Routes = [
  { path: '', component: FashionList },
  { path: 'add', component: FashionForm },
  { path: 'edit/:id', component: FashionForm },
  { path: 'detail/:id', component: FashionDetail }
];