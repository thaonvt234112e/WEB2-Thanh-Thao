import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { FashionService } from '../fashion.service';

@Component({
  selector: 'app-fashion-detail',
  imports: [CommonModule, RouterLink],
  templateUrl: './fashion-detail.html',
  styleUrl: './fashion-detail.css'
})
export class FashionDetail implements OnInit {
  private fashionService = inject(FashionService);
  private route = inject(ActivatedRoute);

  fashion: any = null;

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');

    if (id) {
      this.fashionService.getById(id).subscribe((data: any) => {
        this.fashion = data;
      });
    }
  }
}