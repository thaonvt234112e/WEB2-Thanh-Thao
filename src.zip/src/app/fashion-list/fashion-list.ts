import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterLink } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { FashionService } from '../fashion.service';

@Component({
  selector: 'app-fashion-list',
  imports: [CommonModule, RouterLink, FormsModule],
  templateUrl: './fashion-list.html',
  styleUrl: './fashion-list.css'
})
export class FashionList implements OnInit {
  private fashionService = inject(FashionService);
  private router = inject(Router);

  fashions: any[] = [];
  searchStyle = '';

  ngOnInit(): void {
    this.loadFashions();
  }

  loadFashions() {
    this.fashionService.getAll().subscribe((data: any) => {
      this.fashions = data;
    });
  }

  searchByStyle() {
    if (!this.searchStyle.trim()) {
      this.loadFashions();
      return;
    }

    this.fashionService.getByStyle(this.searchStyle).subscribe((data: any) => {
      this.fashions = data;
    });
  }

  deleteFashion(id: string) {
    if (confirm('Are you sure you want to delete this fashion?')) {
      this.fashionService.delete(id).subscribe(() => {
        this.loadFashions();
      });
    }
  }

  goToEdit(id: string) {
    this.router.navigate(['/edit', id]);
  }

  goToDetail(id: string) {
    this.router.navigate(['/detail', id]);
  }
}