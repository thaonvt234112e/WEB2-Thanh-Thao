import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AngularEditorModule, AngularEditorConfig } from '@kolkov/angular-editor';
import { FashionService } from '../fashion.service';

@Component({
  selector: 'app-fashion-form',
  imports: [CommonModule, FormsModule, RouterLink, AngularEditorModule],
  templateUrl: './fashion-form.html',
  styleUrl: './fashion-form.css'
})
export class FashionForm implements OnInit {
  private fashionService = inject(FashionService);
  private route = inject(ActivatedRoute);
  private router = inject(Router);

  id: string | null = null;

  fashion: any = {
    title: '',
    details: '',
    thumbnail: '',
    style: ''
  };

  editorConfig: AngularEditorConfig = {
    editable: true,
    spellcheck: true,
    height: '250px',
    minHeight: '200px',
    placeholder: 'Enter fashion details here...',
    translate: 'no',
    sanitize: false,
    defaultParagraphSeparator: 'p',
    toolbarPosition: 'top'
  };

  ngOnInit(): void {
    this.id = this.route.snapshot.paramMap.get('id');

    if (this.id) {
      this.fashionService.getById(this.id).subscribe((data: any) => {
        this.fashion = data;
      });
    }
  }

  saveFashion() {
    if (!this.fashion.title || !this.fashion.thumbnail || !this.fashion.style) {
      alert('Please fill all required fields');
      return;
    }

    if (this.id) {
      this.fashionService.update(this.id, this.fashion).subscribe(() => {
        alert('Update successfully');
        this.router.navigate(['/']);
      });
    } else {
      this.fashionService.create(this.fashion).subscribe(() => {
        alert('Create successfully');
        this.router.navigate(['/']);
      });
    }
  }
}